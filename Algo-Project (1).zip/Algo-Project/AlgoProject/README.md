# Convex Hull Animations
The purpose of this project is to provide an animation for the execution of a few popular convex hull algorithms in two dimensions.

The application itself is accessible through a link at the top of this page and via [this](https://ermel272.github.io/convex-hull-animations) link.